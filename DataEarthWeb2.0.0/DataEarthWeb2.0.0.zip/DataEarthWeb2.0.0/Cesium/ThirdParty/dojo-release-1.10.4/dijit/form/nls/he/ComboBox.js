define(
({
		previousMessage: "האפשרויות הקודמות",
		nextMessage: "אפשרויות נוספות"
})
);
